import requests

USER_TOKEN = "EAATEGfMOkHEBRmWsMOcPlP6AEtDGPttQd2FHiAXQaiTnXEZCNbZB5ytpOb2JzyrJD5MM09VTIMmX4MNe57qHYGjUPzpU6pR7FzLpCwuOFwLRul5kwJVzr0r91F2NT6yCbu0URZAfKiXSHGWo1mpGHC0ZB1kIJ3ScT7GSH53sMK5El7UgkN2PXHeBBs92piDVuybxWO3pIVgxwrwMa6Kcyc2wRA6AqDZAUtDULUpmQsUS5GBpOlshiU6833ZCw9285HZAfZBTJzmBHjhGenxxjJfYo6jmejsZD"
PAGE_ID = "101494423041533"

url = f"https://graph.facebook.com/v19.0/me/accounts"
params = {"access_token": USER_TOKEN}

response = requests.get(url, params=params).json()

for page in response.get("data", []):
    if page["id"] == PAGE_ID:
        print(f"Page Access Token: {page['access_token']}")